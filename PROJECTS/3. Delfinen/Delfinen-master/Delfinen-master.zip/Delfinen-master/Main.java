import java.io.*;

public class Main{

   public static void main(String[] args)throws FileNotFoundException,  InterruptedException{
     
      //Start menu
      DelfinenMenu menu = new DelfinenMenu(); 
      menu.startMenu();
   
   }
}