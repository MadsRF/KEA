public class Motionist extends Member{

   //Constructor
   public Motionist(String name,int age,String memberstatus, String memberpart,String membertype, int kontigent){
      super(name,age,memberstatus,memberpart,membertype,kontigent);
   }
}